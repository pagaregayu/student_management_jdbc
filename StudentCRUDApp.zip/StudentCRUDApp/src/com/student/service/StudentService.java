package com.student.service;

import java.util.List;
import com.student.dao.StudentDAO;
import com.student.entity.Student;

public class StudentService {
    private StudentDAO dao = new StudentDAO();

    public void addStudent(Student s) {
        dao.addStudent(s);
    }

    public List<Student> getAllStudents() {
        return dao.getAllStudents();
    }

    public void updateStudent(Student s) {
        dao.updateStudent(s);
    }

    public void deleteStudent(int id) {
        dao.deleteStudent(id);
    }
}
