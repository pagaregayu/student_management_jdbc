package com.student.controller;

import java.util.List;
import java.util.Scanner;
import com.student.entity.Student;
import com.student.service.StudentService;

public class MainController {
    public static void main(String[] args) {
        StudentService service = new StudentService();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Student CRUD ---");
            System.out.println("1. Add Student");
            System.out.println("2. View All Students");
            System.out.println("3. Update Student");
            System.out.println("4. Delete Student");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter Name: ");
                    String name = sc.next();
                    System.out.print("Enter Age: ");
                    int age = sc.nextInt();
                    service.addStudent(new Student(0, name, age));
                    break;
                case 2:
                    List<Student> students = service.getAllStudents();
                    students.forEach(System.out::println);
                    break;
                case 3:
                    System.out.print("Enter ID to Update: ");
                    int uid = sc.nextInt();
                    System.out.print("Enter New Name: ");
                    String uname = sc.next();
                    System.out.print("Enter New Age: ");
                    int uage = sc.nextInt();
                    service.updateStudent(new Student(uid, uname, uage));
                    break;
                case 4:
                    System.out.print("Enter ID to Delete: ");
                    int did = sc.nextInt();
                    service.deleteStudent(did);
                    break;
                case 5:
                    System.out.println("Exiting...");
                    sc.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }
}
