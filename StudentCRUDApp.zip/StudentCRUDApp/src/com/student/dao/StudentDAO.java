package com.student.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.student.entity.Student;

public class StudentDAO {
    private final String url = "jdbc:mysql://localhost:3306/studentdb";
    private final String user = "root";
    private final String password = "pass";

    // Create Connection
    private Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(url, user, password);
    }

    // Insert Student
    public void addStudent(Student s) {
        String sql = "INSERT INTO students(name, age) VALUES(?, ?)";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, s.getName());
            ps.setInt(2, s.getAge());
            ps.executeUpdate();
            System.out.println("Student Added!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Get All Students
    public List<Student> getAllStudents() {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT * FROM students";
        try (Connection con = getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new Student(rs.getInt("id"),
                                     rs.getString("name"),
                                     rs.getInt("age")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // Update Student
    public void updateStudent(Student s) {
        String sql = "UPDATE students SET name=?, age=? WHERE id=?";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, s.getName());
            ps.setInt(2, s.getAge());
            ps.setInt(3, s.getId());
            ps.executeUpdate();
            System.out.println("Student Updated!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Delete Student
    public void deleteStudent(int id) {
        String sql = "DELETE FROM students WHERE id=?";
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Student Deleted!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
